<?php
require_once 'includes.php'; if(logged_in()) redirect('index.php'); $error=''; $v=['full_name'=>'','username'=>'','email'=>'','contact_number'=>''];
if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf();
    foreach($v as $k=>$_) $v[$k]=trim($_POST[$k]??'');
    $pass=$_POST['password']??''; $confirm=$_POST['confirm_password']??''; $code=trim($_POST['admin_code']??'');
    if(!hash_equals((string)$ADMIN_CODE,$code)) $error='Invalid Admin access code. Ask the current administrator for it.';
    elseif($v['contact_number']!==''&&!preg_match('/^\d{11}$/',$v['contact_number'])) $error='Contact number must be exactly 11 digits.';
    elseif(norm_email($v['email'])===null&&$v['email']!=='') $error='Please use your school email ending in @smcbi.edu.ph (example: juan@smcbi.edu.ph).';
    elseif(!$v['full_name']||!$v['username']||norm_email($v['email'])===null||strlen($pass)<8) $error='Complete all fields. Password must be at least 8 characters.';
    elseif($pass!==$confirm) $error='Passwords do not match.';
    else{
        try{
            $has=function($col,$val) use($pdo){ $q=$pdo->prepare("SELECT COUNT(*) FROM users WHERE $col=?"); $q->execute([$val]); return (int)$q->fetchColumn()>0; };
            if($has('username',$v['username'])) $error='That username is already taken.';
            elseif($has('email',$v['email'])) $error='That email is already registered.';
            else{
                $pdo->prepare("INSERT INTO users(full_name,username,email,password_hash,role,contact_number) VALUES(?,?,?,?,'admin',?)")
                    ->execute([$v['full_name'],$v['username'],norm_email($v['email']),password_hash($pass,PASSWORD_DEFAULT),$v['contact_number']]);
                redirect('login.php?role=admin&registered=admin');
            }
        }catch(PDOException $e){ $error='Could not create the account.'.(!empty($DEBUG)?' Details: '.$e->getMessage():''); }
    }
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Create Admin Account | Club Membership &amp; Attendance</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link rel="icon" type="image/svg+xml" href="favicon.svg"><link rel="stylesheet" href="smcbi-theme.css?v=<?=css_ver()?>"></head><body><div class="login-shell"><div class="login-card card p-4 p-md-5" style="max-width:640px">
<div class="text-center mb-4"><div class="mx-auto mb-3 brand-logo-lg"><?=brand_logo()?></div><h2>Create Admin Account</h2><p class="text-muted">For club administrators only.</p></div>
<?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?>
<form method="post" class="row g-3"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
<div class="col-12"><label class="form-label">Admin Access Code *</label><input class="form-control" name="admin_code" autocomplete="off" required></div>
<div class="col-md-6"><label class="form-label">Full Name *</label><input class="form-control" name="full_name" value="<?=e($v['full_name'])?>" required></div>
<div class="col-md-6"><label class="form-label">Username *</label><input class="form-control" name="username" value="<?=e($v['username'])?>" required></div>
<div class="col-md-6"><label class="form-label">Email *</label><?=email_input('email',$v['email'])?></div>
<div class="col-md-6"><label class="form-label">Contact Number</label><?=phone_input($v['contact_number'])?></div>
<div class="col-md-6"><label class="form-label">Password * (min 8)</label><input type="password" class="form-control" name="password" minlength="8" required></div>
<div class="col-md-6"><label class="form-label">Confirm Password *</label><input type="password" class="form-control" name="confirm_password" minlength="8" required></div>
<div class="col-12 d-grid"><button class="btn btn-primary btn-lg">Create Admin Account</button></div></form>
<div class="text-center mt-4"><a href="login.php?role=admin">Back to Admin Login</a></div></div></div></body></html>
