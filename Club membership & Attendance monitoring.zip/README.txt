CLUB MEMBERSHIP & ATTENDANCE MONITORING SYSTEM - SMCBI (completed build)

SETUP (InfinityFree)
1. Create a MySQL database; put host/name/user/password in config.php.
2. Upload all files to htdocs/ (keep the uploads/ folder).
3. Open /setup.php once (creates/upgrades tables, creates the first Administrator). Then delete setup.php.
4. Log in, add Officer/Adviser accounts under Users.
Upgrading an existing install: just upload the new files and open /setup.php again (adds users.student_id and activities.reminder_sent).

WHAT WAS COMPLETED / FIXED IN THIS BUILD
- Student ID is now saved at registration (it was collected but discarded, so ID search could never match real IDs).
- Profile photo can be uploaded at registration and is copied to the member record for attendance verification.
- MySQL session time zone forced to Asia/Manila (+08:00) so Ongoing/Completed and late-after logic use school time.
- Activity statuses refresh on every page load; one-time reminder notification the day before an activity.
- Activity edit/cancel now notify users (edit no longer says "New Club Activity"); cancelling closes attendance.
- Manual attendance: blank "skip" default (no more accidental mark-everyone-Present), never overwrites existing records, notifies students.
- Close Attendance only runs when attendance is Open.
- Reports: rate = (Present+Late) / recorded entries (was miscounted); new per-member attendance report; Activity CSV + Member CSV.
- Members: Edit modal (officer/admin) and photo thumbnails.
- Membership: pending applicants cannot re-apply; resubmission after rejection works.
- Login throttle (5 failed attempts / 10 minutes), httponly+SameSite session cookie, logout cookie bug fixed.

SECURITY NOTES
- config.php contains your database password. Because it was shared outside the server, reset the MySQL password in InfinityFree and update config.php.
- Prepared statements, CSRF tokens, role checks, escaped output, upload validation (type + size), and uploads/ PHP execution block are in place.
- Users created before this update have no Student ID; their member records show a generated STU-xxxxx ID. Edit them in Members or have students re-register.

UPDATE (login fix + roles)
- Login errors: config.php now shows the real error message instead of a blank "unable to handle" page ($DEBUG = true). Set $DEBUG = false when everything works.
- Login pages: Student login, Officer login and Admin login (login.php?role=student|officer|admin). Each only accepts its own role. Advisers can still sign in at plain login.php.
- Register as Student or Officer. Officer registration requires the access code in config.php ($OFFICER_CODE) - change it and share it only with real officers.
- Administrator accounts are still created in setup.php / Users page only.

UPDATE (database repair)
- Error "Unknown column 'email'" means the database still has tables from an older version. Open /setup.php: it now detects mismatched tables, lists the missing columns, and offers "Reset & Rebuild Database" (type RESET). Then create the Administrator again.
- setup.php no longer crashes after creating the admin (it was missing a helper function).

- setup.php also has "Keep my existing accounts & rebuild everything else" for databases created by the old version (keeps users/passwords, rebuilds the rest).

UPDATE (admin accounts)
- add_admin.sql inserts the first Administrator into the existing database (import it once in phpMyAdmin).
- Users page (Admin): Create Account for Student / Officer / Adviser / Administrator. Students get Student ID, program, year, optional photo, and an option to be an active member immediately. Also search/filter, change role, reset password, delete.
- Student and officer self-registration writes to the `users` table. A student gets a row in `members` when they apply (or when an admin ticks "active club member").

UPDATE (clubs + separate account forms)
- Clubs: Sport Circa, Canva, Harmonics, Mother Ignacia, Red Cross (edit club_list() in includes.php to change).
- Students pick a club when applying (Join Club). The club shows in Applications, Members (filter + edit), the student dashboard and Reports (Members per Club).
- The website adds the `club` columns automatically on first load; add_clubs.sql does the same manually.
- Admin > Users now has two separate forms: Create Student Account (with club + optional instant membership) and Create Admin / Staff Account (Administrator, Officer, Adviser).

UPDATE (separate admin sign-up)
- Admin Login now links to register_admin.php (Create Admin Account). It needs the Admin Access Code from config.php ($ADMIN_CODE, default SMCBI-ADMIN-2026 - CHANGE IT).
- Student Login links to register.php (student), Officer Login links to register.php?type=officer.

UPDATE (rejected applications)
- Rejecting an application now has an optional reason box. The student gets a notification with the reason and sees a red "rejected" notice (club, reason, date) on their dashboard with an "Apply Again" button.
- Re-applying creates a new application and keeps the old one in the history. Inactive (deactivated) members cannot re-apply; they must contact an officer.
- The review_note column is added automatically on first load.

UPDATE (IT course, Student ID and phone rules)
- Course list now includes BSIT - Bachelor of Science in Information Technology (student sign-up, admin Create Student, officer Edit Member). Edit the list in includes.php > program_list().
- Student ID: the letter C is fixed in front of the box; type exactly 6 numbers (stored as C240111). Enforced in the browser and on the server (admin-created students too).
- Contact number: exactly 11 digits (numbers only). Optional, but if filled it must be 11 digits. Applies to student/officer/admin sign-up, admin Create Student/Staff, Profile and Edit Member.
- Existing accounts keep their data; an old number that is not 11 digits must be corrected the next time that profile is saved.

UPDATE (admin-only close, club editing)
- Attendance: only the Administrator can Close Attendance. Officers can still open attendance and record it; their Close button is disabled and the server rejects a close request from an officer.
- Admin > Users now has a Club column, an "Edit club" button for each student, and a club filter. Changing a club notifies the student. If a student has no membership record yet, choosing a club adds them as an active member of that club. Choosing "No club" removes the club.
- Officers/admins can still change a member's club in Members > Edit.

UPDATE (Users page layout)
- Users table fits normal laptop screens: Program shows the short code (BSIT) with the full name on hover, Actions stack in two rows, and the top menu no longer spills past the page edge on 1000-1280px screens.

UPDATE (name)
- The system is now named "Club Membership & Attendance" everywhere (menu, page titles, login, landing page, footer, setup). Because the longer name needs room, the top menu turns into a hamburger button below 1200px wide.
UPDATE: Members page now has numbered pagination (« 1 2 3 … 132 133 »); every email field must be a school email ending in @smcbi.edu.ph (register, admin sign-up, Users page, profile, setup).
UPDATE: modals centred with tidy two-column layout; navbar collapses to hamburger below 1400px (no more clipped menu); refreshed look (cards, tables, buttons, inputs).
UPDATE: Academic club is automatic from the program (BSIT = SITES; edit academic_club_map() in includes.php to add the others). Shown on sign-up, student dashboard, profile, Members and Users pages. Club the student joins stays the non-academic one.
UPDATE: phone-friendly UI (tables turn into cards on phones, stacked buttons/filters, full-width pop-ups, larger tap targets).
UPDATE: layout checked for iPhone SE/16/16 Pro Max, Pixel 9/10, Galaxy A55, Fold (folded+open), iPad Mini/Pro, Surface Pro, Nest Hub; cards layout used up to 991px.
UPDATE: new logo (logo.svg, logo.png, favicon.svg) used in the menu, login, sign-up, landing and setup pages and as the browser-tab icon.
UPDATE: logo is now built into the pages (no separate image file needed for the menu/login).
UPDATE: wide-screen menu bar widened/compacted so the user name no longer spills out of the white bar.
UPDATE: stylesheet link now changes automatically whenever smcbi-theme.css changes, so browsers always load the newest look.
UPDATE: Applications page shows the applicant's academic club.
UPDATE: page numbers + 'Per page' (10/25/50/100) on Members, Users, Applications, Activities and Notifications; works for any number of students.
UPDATE: page numbers show 1-10 then ... then the last two pages, like the sample picture.
UPDATE: all confirmations (approve, reject, delete, close attendance, etc.) now use a centered in-page dialog instead of the browser's box at the top of Chrome.
UPDATE: one-time officer codes. Admin > Users > 'Officer Codes' generates a code per officer (valid 1/3/7/30 days, works once). The shared $OFFICER_CODE in config.php still works; set it to '' to turn it off.
