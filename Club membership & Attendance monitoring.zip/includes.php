<?php
require_once __DIR__ . '/config.php';

function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function redirect($url){ header('Location: '.$url); exit; }
function logged_in(){ return !empty($_SESSION['user_id']); }
function current_role(){ return $_SESSION['role'] ?? null; }
function require_login(){ if(!logged_in()) redirect('login.php'); }
function require_roles($roles){ require_login(); if(!in_array(current_role(), $roles, true)) { http_response_code(403); render_error('Access denied','You do not have permission to open this page.'); exit; } }
function require_officer(){ require_roles(['admin','officer']); }
function require_admin(){ require_roles(['admin']); }
function require_adviser_or_staff(){ require_roles(['admin','officer','adviser']); }
function csrf_token(){ if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function verify_csrf(){ if(!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); render_error('Security check failed','Please go back and try again.'); exit; } }
function flash($message,$type='success'){ $_SESSION['flash']=['message'=>$message,'type'=>$type]; }
function get_flash(){ $f=$_SESSION['flash']??null; unset($_SESSION['flash']); return $f; }
function notify_user($uid,$title,$message,$type='info'){ if(!$uid)return; global $pdo; $st=$pdo->prepare('INSERT INTO notifications(user_id,title,message,type) VALUES(?,?,?,?)'); $st->execute([$uid,$title,$message,$type]); }
function notify_roles($roles,$title,$message,$type='info'){ global $pdo; if(!$roles)return; $in=implode(',',array_fill(0,count($roles),'?')); $st=$pdo->prepare("SELECT id FROM users WHERE role IN ($in)"); $st->execute($roles); foreach($st as $r) notify_user($r['id'],$title,$message,$type); }
function member_for_user($uid){ global $pdo; $st=$pdo->prepare('SELECT * FROM members WHERE user_id=? LIMIT 1'); $st->execute([$uid]); return $st->fetch(); }
function badge($status){ $map=['Active'=>'success','Inactive'=>'secondary','Pending'=>'warning text-dark','Rejected'=>'danger','Upcoming'=>'info text-dark','Ongoing'=>'success','Completed'=>'secondary','Cancelled'=>'danger','Present'=>'success','Late'=>'warning text-dark','Absent'=>'danger']; $c=$map[$status]??'secondary'; return '<span class="badge bg-'.$c.'">'.e($status).'</span>'; }
function render_error($title,$message){ echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.e($title).'</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link rel="icon" type="image/svg+xml" href="favicon.svg"><link rel="stylesheet" href="smcbi-theme.css?v=20261019"></head><body><main class="container py-5"><div class="card p-5 text-center"><h2>'.e($title).'</h2><p class="text-muted">'.e($message).'</p><a href="index.php" class="btn btn-primary">Back to System</a></div></main></body></html>'; }
function nav_active($page){ return basename($_SERVER['PHP_SELF'])===$page?'active':''; }
function header_html($title){
    $flash=get_flash(); $role=current_role(); $unread=0;
    if(logged_in()){ global $pdo; $st=$pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0'); $st->execute([$_SESSION['user_id']]); $unread=(int)$st->fetchColumn(); }
    ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="csrf-token" content="<?=e(csrf_token())?>"><title><?=e($title)?> | Club Membership &amp; Attendance</title><link rel="preconnect" href="https://cdn.jsdelivr.net"><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet"><link rel="icon" type="image/svg+xml" href="favicon.svg"><link rel="stylesheet" href="smcbi-theme.css?v=<?=css_ver()?>"></head><body><div class="smcbi-top-accent"></div>
<?php if(logged_in()): ?><nav class="navbar navbar-expand-xxl smcbi-navbar"><div class="container"><a class="navbar-brand smcbi-brand d-flex align-items-center gap-2" href="index.php"><span class="brand-logo-wrap"><?=brand_logo()?></span><span><span class="smcbi-brand-name">Club Membership &amp; Attendance</span><small class="smcbi-brand-sub">ST. MARY'S COLLEGE OF BANSALAN</small></span></a><button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="nav"><ul class="navbar-nav me-auto mb-2 mb-xxl-0">
<li class="nav-item"><a class="nav-link <?=nav_active('index.php')?>" href="index.php"><i class="bi bi-grid-1x2 me-1"></i>Dashboard</a></li>
<?php if($role==='member'): ?><li class="nav-item"><a class="nav-link <?=nav_active('activities.php')?>" href="activities.php"><i class="bi bi-calendar-event me-1"></i>Activities</a></li><li class="nav-item"><a class="nav-link <?=nav_active('my_attendance.php')?>" href="my_attendance.php"><i class="bi bi-check2-square me-1"></i>My Attendance</a></li>
<?php else: ?><li class="nav-item"><a class="nav-link <?=nav_active('members.php')?>" href="members.php"><i class="bi bi-people me-1"></i>Members</a></li><li class="nav-item"><a class="nav-link <?=nav_active('applications.php')?>" href="applications.php"><i class="bi bi-person-check me-1"></i>Applications</a></li><li class="nav-item"><a class="nav-link <?=nav_active('activities.php')?>" href="activities.php"><i class="bi bi-calendar-event me-1"></i>Activities</a></li><li class="nav-item"><a class="nav-link <?=nav_active('attendance.php')?>" href="attendance.php"><i class="bi bi-clipboard-check me-1"></i>Attendance</a></li><li class="nav-item"><a class="nav-link <?=nav_active('reports.php')?>" href="reports.php"><i class="bi bi-bar-chart me-1"></i>Reports</a></li><?php endif; ?>
<?php if($role==='admin'): ?><li class="nav-item"><a class="nav-link <?=nav_active('users.php')?>" href="users.php"><i class="bi bi-shield-lock me-1"></i>Users</a></li><?php endif; ?>
<?php if($role==='adviser'): ?><li class="nav-item"><a class="nav-link <?=nav_active('reports.php')?>" href="reports.php"><i class="bi bi-bar-chart me-1"></i>Reports</a></li><?php endif; ?></ul><ul class="navbar-nav align-items-xxl-center"><li class="nav-item"><a class="nav-link position-relative <?=nav_active('notifications.php')?>" href="notifications.php"><i class="bi bi-bell"></i><?php if($unread): ?><span class="notification-dot"><?=$unread>99?'99+':$unread?></span><?php endif; ?></a></li><li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"><i class="bi bi-person-circle me-1"></i><?=e($_SESSION['full_name']??'User')?></a><ul class="dropdown-menu dropdown-menu-end"><li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i>Profile</a></li><li><hr class="dropdown-divider"></li><li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li></ul></li></ul></div></div></nav><?php endif; ?><main class="container py-4 smcbi-page-shell"><?php if($flash): ?><div class="alert alert-<?=e($flash['type'])?> alert-dismissible fade show"><i class="bi bi-info-circle me-2"></i><?=e($flash['message'])?><button class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
<?php }
function footer_html(){ ?></main><footer class="smcbi-footer"><div class="container d-flex justify-content-between flex-wrap gap-2"><span><strong>Club Membership &amp; Attendance</strong> · St. Mary's College of Bansalan, Inc.</span><span>Monitoring System</span></div></footer><div class="modal fade" id="confirmModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-dialog-centered modal-sm-confirm"><div class="modal-content text-center"><div class="modal-body py-4 px-4"><div id="confirmIcon" class="confirm-icon is-ok">&#10003;</div><h5 id="confirmTitle" class="mb-2">Confirm action</h5><p id="confirmMsg" class="text-muted mb-4"></p><div class="d-flex gap-2 justify-content-center"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-primary" id="confirmOk">Confirm</button></div></div></div></div></div><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script><script>document.querySelectorAll('table.table').forEach(function(t){var h=[].map.call(t.querySelectorAll('thead th'),function(x){return x.textContent.trim()});if(!h.length||t.querySelector('td[colspan]')&&t.querySelectorAll('tbody tr').length===1)return;t.classList.add('mstack');t.querySelectorAll('tbody tr').forEach(function(r){[].forEach.call(r.children,function(c,i){if(c.tagName==='TD'&&h[i]!==undefined)c.setAttribute('data-label',h[i])})})});</script><script>(function(){var box=document.getElementById('confirmModal');if(!box||!window.bootstrap){document.querySelectorAll('[data-confirm]').forEach(function(el){el.addEventListener('click',function(e){if(!confirm(el.dataset.confirm))e.preventDefault();});});return;}
var modal=bootstrap.Modal.getOrCreateInstance(box),msg=document.getElementById('confirmMsg'),ttl=document.getElementById('confirmTitle'),ok=document.getElementById('confirmOk'),ic=document.getElementById('confirmIcon'),pending=null;
document.addEventListener('click',function(e){var el=e.target.closest('[data-confirm]');if(!el)return;e.preventDefault();pending=el;var danger=/danger/.test(el.className);var label=(el.textContent||'').trim()||'Confirm';
ttl.textContent=danger?'Please confirm':'Confirm action';msg.textContent=el.getAttribute('data-confirm');ok.textContent=label;ok.className='btn '+(danger?'btn-danger':'btn-primary');ic.className='confirm-icon '+(danger?'is-danger':'is-ok');ic.innerHTML=danger?'&#9888;':'&#10003;';modal.show();});
ok.addEventListener('click',function(){var el=pending;pending=null;modal.hide();if(!el)return;var f=el.form||el.closest('form');if(!f){if(el.href)location.href=el.href;return;}
if(f.checkValidity&&!f.checkValidity()){f.reportValidity();return;}
if(f.requestSubmit){f.requestSubmit(el);}else{if(el.name){var h=document.createElement('input');h.type='hidden';h.name=el.name;h.value=el.value;f.appendChild(h);}f.submit();}});
box.addEventListener('shown.bs.modal',function(){var b=document.querySelectorAll('.modal-backdrop');if(b.length)b[b.length-1].style.zIndex=1075;});})();</script></body></html><?php }

function save_photo($f,$prefix='u'){
    if(!$f||($f['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE) return null;
    if($f['error']!==UPLOAD_ERR_OK||$f['size']>2*1024*1024) return false;
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime]??null;
    if(!$ext||!@getimagesize($f['tmp_name'])) return false;
    $dir=__DIR__.'/uploads'; if(!is_dir($dir)) mkdir($dir,0755,true);
    $path='uploads/'.$prefix.'_'.bin2hex(random_bytes(6)).'.'.$ext;
    return move_uploaded_file($f['tmp_name'],__DIR__.'/'.$path)?$path:false;
}
function refresh_activity_statuses(){
    global $pdo;
    $pdo->exec("UPDATE activities SET status=CASE WHEN status='Cancelled' THEN 'Cancelled' WHEN activity_date<CURDATE() OR (activity_date=CURDATE() AND end_time<CURTIME()) THEN 'Completed' WHEN activity_date=CURDATE() AND start_time<=CURTIME() AND end_time>=CURTIME() THEN 'Ongoing' ELSE 'Upcoming' END");
    try{ // one-time reminder the day before an activity
        $rows=$pdo->query("SELECT id,activity_name,start_time,location FROM activities WHERE status='Upcoming' AND reminder_sent=0 AND activity_date=CURDATE()+INTERVAL 1 DAY")->fetchAll();
        foreach($rows as $a){
            $ids=$pdo->query("SELECT user_id FROM members WHERE status='Active' AND user_id IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN);
            foreach($ids as $uid) notify_user($uid,'Activity Reminder',$a['activity_name'].' is tomorrow at '.date('g:i A',strtotime($a['start_time'])).' ('.$a['location'].').','activity');
            $pdo->prepare('UPDATE activities SET reminder_sent=1 WHERE id=?')->execute([$a['id']]);
        }
    }catch(PDOException $e){}
}

// ---- Account field rules: course list, Student ID (C + 6 digits), phone (11 digits) ----
function program_list(){ return ['BEED - Bachelor of Elementary Education','BSED - Bachelor of Secondary Education','BSBA - Bachelor of Science in Business Administration','BSHM - Bachelor of Science in Hospitality Management','BSIT - Bachelor of Science in Information Technology']; }
// Accepts "240111" or "C240111"; returns "C240111", or null when invalid.
function norm_student_id($v){ $v=strtoupper(trim((string)$v)); return preg_match('/^C?(\d{6})$/',$v,$m)?'C'.$m[1]:null; }
// Empty is allowed (optional field); otherwise exactly 11 digits. Returns null when invalid.

const SCHOOL_DOMAIN='smcbi.edu.ph';
function norm_email($v){ $v=strtolower(trim((string)$v)); return (filter_var($v,FILTER_VALIDATE_EMAIL)&&preg_match('/@smcbi\.edu\.ph$/',$v))?$v:null; }
function email_input($name='email',$val='',$extra=''){ return '<input type="email" class="form-control" name="'.e($name).'" value="'.e($val).'" placeholder="example@smcbi.edu.ph" pattern="[A-Za-z0-9._%+\-]+@smcbi\.edu\.ph" title="Use your school email, e.g. example@smcbi.edu.ph" required '.$extra.'><div class="small-muted">School email only (@smcbi.edu.ph)</div>'; }
function paginate($total,$per=10){ $pp=(int)($_GET['per']??0); if(in_array($pp,[10,25,50,100],true))$per=$pp; $pages=max(1,(int)ceil($total/$per)); $p=max(1,min($pages,(int)($_GET['page']??1))); return ['page'=>$p,'pages'=>$pages,'per'=>$per,'offset'=>($p-1)*$per,'total'=>$total]; }
function pagination_html($pg){
  if($pg['pages']<=1) return '';
  $cur=$pg['page'];$last=$pg['pages'];
  $qs=$_GET;unset($qs['page']);
  $url=function($n) use($qs){ $q=$qs;$q['page']=$n;return '?'.http_build_query($q); };
  if($last<=12){$nums=range(1,$last);}
  elseif($cur<=7){$nums=array_merge(range(1,10),[$last-1,$last]);}
  elseif($cur>=$last-6){$nums=array_merge([1,2],range($last-9,$last));}
  else{$nums=array_merge([1,2],range($cur-3,$cur+3),[$last-1,$last]);}
  $nums=array_values(array_unique(array_filter($nums,function($n) use($last){return $n>=1&&$n<=$last;})));sort($nums);
  $h='<nav aria-label="Pages"><ul class="pagination smcbi-pager">';
  $h.=$cur>1?'<li class="page-item"><a class="page-link" href="'.e($url($cur-1)).'" aria-label="Previous">&laquo;</a></li>':'<li class="page-item disabled"><span class="page-link">&laquo;</span></li>';
  $prev=0;
  foreach($nums as $n){
    if($prev&&$n>$prev+1)$h.='<li class="page-item disabled"><span class="page-link">&hellip;</span></li>';
    $h.=$n===$cur?'<li class="page-item active"><span class="page-link">'.$n.'</span></li>':'<li class="page-item"><a class="page-link" href="'.e($url($n)).'">'.$n.'</a></li>';
    $prev=$n;
  }
  $h.=$cur<$last?'<li class="page-item"><a class="page-link" href="'.e($url($cur+1)).'" aria-label="Next">&raquo;</a></li>':'<li class="page-item disabled"><span class="page-link">&raquo;</span></li>';
  return $h.'</ul></nav>';
}
function pager_bar($pg,$label='records'){
  if($pg['total']<=0) return '';
  $qs=$_GET;unset($qs['page'],$qs['per']);
  $hid='';foreach($qs as $k=>$v){ if(is_scalar($v)) $hid.='<input type="hidden" name="'.e($k).'" value="'.e($v).'">'; }
  $sel='';foreach([10,25,50,100] as $n)$sel.='<option value="'.$n.'"'.($pg['per']==$n?' selected':'').'>'.$n.'</option>';
  $to=min($pg['total'],$pg['offset']+$pg['per']);
  return '<div class="pager-bar d-flex flex-wrap justify-content-between align-items-center gap-2 mt-2"><div class="small-muted">Showing '.($pg['offset']+1).'&ndash;'.$to.' of '.number_format($pg['total']).' '.e($label).'</div><div class="d-flex flex-wrap align-items-center gap-2"><form method="get" class="d-flex align-items-center gap-1 m-0">'.$hid.'<label class="small-muted mb-0">Per page</label><select class="form-select form-select-sm w-auto" name="per" onchange="this.form.submit()">'.$sel.'</select></form>'.pagination_html($pg).'</div></div>';
}
function norm_phone($v){ $v=trim((string)$v); if($v==='') return ''; return preg_match('/^\d{11}$/',$v)?$v:null; }
function sid_input($val='',$required=false){
    $d=substr(preg_replace('/\D/','',(string)$val),0,6);
    return '<div class="input-group"><span class="input-group-text fw-bold">C</span><input class="form-control" name="student_id" inputmode="numeric" pattern="[0-9]{6}" minlength="6" maxlength="6" placeholder="240111" title="6 digits after the C" value="'.e($d).'"'.($required?' required':'').' oninput="this.value=this.value.replace(/\D/g,\'\').slice(0,6)"></div><div class="small-muted">The ID always starts with C, then 6 numbers (example: C240111).</div>';
}
function phone_input($val=''){
    return '<input class="form-control" name="contact_number" inputmode="numeric" pattern="[0-9]{11}" minlength="11" maxlength="11" placeholder="09123456789" title="11 digits" value="'.e($val).'" oninput="this.value=this.value.replace(/\D/g,\'\').slice(0,11)">';
}
// Academic club is automatic, based on the student's program. Add more programs here when the names are known.
function academic_club_map(){ return ['BSIT'=>'SITES']; }
function academic_club($course){ $c=strtoupper(trim((string)strtok((string)$course,' '))); return academic_club_map()[$c]??null; }
function academic_club_field($id='acadClub'){ return '<input class="form-control" id="'.$id.'" value="Select a program first" disabled>'; }
function academic_club_js($selectName='course',$id='acadClub'){ return '<script>(function(){var m='.json_encode(academic_club_map()).';var s=document.querySelector("select[name='.$selectName.']"),o=document.getElementById("'.$id.'");if(!s||!o)return;function u(){var c=(s.value||"").split(" ")[0].toUpperCase();o.value=!s.value?"Select a program first":(m[c]||"No academic club yet");}s.addEventListener("change",u);u();})();</script>'; }
function brand_logo(){ return '<svg class="brand-logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" role="img" aria-label="Club Membership &amp; Attendance logo"><defs><linearGradient id="lg1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0b72d9"/><stop offset="1" stop-color="#0a1c3d"/></linearGradient></defs><path d="M60 6 104 22v34c0 29-18 49-44 58C34 105 16 85 16 56V22Z" fill="url(#lg1)"/><path d="M60 6 104 22v34c0 29-18 49-44 58C34 105 16 85 16 56V22Z" fill="none" stroke="#ffd84d" stroke-width="4"/><circle cx="44" cy="40" r="8" fill="#fff"/><path d="M29 66c0-10 7-17 15-17s15 7 15 17Z" fill="#fff"/><circle cx="76" cy="40" r="8" fill="#fff" opacity=".85"/><path d="M61 66c0-10 7-17 15-17s15 7 15 17Z" fill="#fff" opacity=".85"/><circle cx="60" cy="82" r="17" fill="#ffd84d"/><path d="m51 82 7 7 13-15" fill="none" stroke="#0a1c3d" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/></svg>'; }
function css_ver(){ return @filemtime(__DIR__.'/smcbi-theme.css')?:'1'; }
function ensure_officer_codes(){
    global $pdo; if(!empty($_SESSION['oc_v1'])) return;
    try{ $pdo->exec("CREATE TABLE IF NOT EXISTS officer_codes(id INT AUTO_INCREMENT PRIMARY KEY,code VARCHAR(30) NOT NULL UNIQUE,note VARCHAR(120) NULL,created_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,expires_at DATETIME NULL,used_by INT NULL,used_at DATETIME NULL) ENGINE=InnoDB"); $_SESSION['oc_v1']=1; }catch(PDOException $e){}
}
function gen_officer_code(){ $a='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; $s=''; for($i=0;$i<8;$i++)$s.=$a[random_int(0,strlen($a)-1)]; return 'OFF-'.substr($s,0,4).'-'.substr($s,4); }
// Returns ['ok'=>bool,'id'=>int|null]. A one-time code made by the administrator, or the shared code in config.php (if one is set).
function officer_code_check($raw){
    global $pdo,$OFFICER_CODE; $raw=strtoupper(trim((string)$raw)); if($raw==='') return ['ok'=>false,'id'=>null];
    ensure_officer_codes();
    try{ $q=$pdo->prepare("SELECT id FROM officer_codes WHERE code=? AND used_by IS NULL AND (expires_at IS NULL OR expires_at>NOW())"); $q->execute([$raw]); $id=$q->fetchColumn(); if($id) return ['ok'=>true,'id'=>(int)$id]; }catch(PDOException $e){}
    if(!empty($OFFICER_CODE)&&hash_equals(strtoupper((string)$OFFICER_CODE),$raw)) return ['ok'=>true,'id'=>null];
    return ['ok'=>false,'id'=>null];
}
function club_list(){ return ['Sport Circa','Canva','Harmonics','Mother Ignacia','Red Cross']; }
function ensure_club_columns(){
    global $pdo; if(!empty($_SESSION['schema_v3'])) return;
    try{ foreach(['members','membership_applications'] as $t){ if(!$pdo->query("SHOW COLUMNS FROM `$t` LIKE 'club'")->fetchColumn()) $pdo->exec("ALTER TABLE `$t` ADD COLUMN club VARCHAR(60) NULL"); } if(!$pdo->query("SHOW COLUMNS FROM `membership_applications` LIKE 'review_note'")->fetchColumn()) $pdo->exec("ALTER TABLE `membership_applications` ADD COLUMN review_note VARCHAR(255) NULL"); $_SESSION['schema_v3']=1; }catch(PDOException $e){}
}
ensure_club_columns();
if(logged_in()) refresh_activity_statuses();
