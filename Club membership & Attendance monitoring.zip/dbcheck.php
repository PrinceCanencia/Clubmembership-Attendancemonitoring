<?php
// Club Membership & Attendance - connection check. Open /dbcheck.php, read the result, then DELETE this file.
error_reporting(E_ALL); ini_set('display_errors','1');
require_once 'config.php';
function row($ok,$label,$detail=''){ echo '<tr><td style="width:60px;font-size:20px">'.($ok?'✅':'❌').'</td><td><b>'.htmlspecialchars($label).'</b>'.($detail!==''?'<div style="color:#555;font-size:13px">'.htmlspecialchars($detail).'</div>':'').'</td></tr>'; }
?><!doctype html><html><head><meta charset="utf-8"><title>Database check | Club Membership &amp; Attendance</title></head><body style="font-family:Arial;max-width:760px;margin:30px auto;padding:0 12px"><h2>Database connection check</h2><table cellpadding="8" style="width:100%;border-collapse:collapse">
<?php
row(true,'Config loaded','Host: '.$DB_HOST.' | Database: '.$DB_NAME.' | User: '.$DB_USER.' | PHP '.PHP_VERSION);
if(!isset($pdo)){ row(false,'Database connection','No $pdo object. Check DB host, name, user and password in config.php.'); echo '</table></body></html>'; exit; }
try{ $pdo->query('SELECT 1'); row(true,'Connected to MySQL'); }catch(Throwable $e){ row(false,'Connected to MySQL',$e->getMessage()); echo '</table></body></html>'; exit; }
$need=['users'=>['id','student_id','full_name','username','email','password_hash','role','course','year_level','profile_photo','contact_number'],
 'members'=>['id','user_id','student_id','full_name','course','year_level','status','club'],
 'membership_applications'=>['id','user_id','member_id','reason','status','club'],
 'activities'=>['id','activity_name','activity_date','status','attendance_status'],
 'attendance'=>['id','activity_id','user_id','status'],
 'notifications'=>['id','user_id','title','message'],'system_settings'=>['id','club_name']];
$allok=true;
foreach($need as $t=>$cols){
  try{ $have=array_column($pdo->query("SHOW COLUMNS FROM `$t`")->fetchAll(),'Field'); $miss=array_diff($cols,$have);
       if($miss){ $allok=false; row(false,"Table $t",'Missing columns: '.implode(', ',$miss)); }
       else row(true,"Table $t",(int)$pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn().' row(s)'); }
  catch(Throwable $e){ $allok=false; row(false,"Table $t",'Missing table: '.$e->getMessage()); }
}
if($allok){
  try{ $pdo->beginTransaction();
       $u='zz_test_'.bin2hex(random_bytes(3));
       $pdo->prepare("INSERT INTO users(student_id,full_name,username,email,password_hash,role,course,year_level,contact_number,profile_photo) VALUES(?,?,?,?,?,?,?,?,?,?)")
           ->execute([$u,'Test User',$u,$u.'@test.local',password_hash('x',PASSWORD_DEFAULT),'member','BEED','1st Year','',null]);
       $pdo->rollBack(); row(true,'Can save a new account (test rolled back, nothing kept)'); }
  catch(Throwable $e){ if($pdo->inTransaction())$pdo->rollBack(); row(false,'Can save a new account',$e->getMessage()); }
}
try{ $r=$pdo->query("SELECT role,COUNT(*) c FROM users GROUP BY role")->fetchAll(PDO::FETCH_KEY_PAIR); row(true,'Accounts by role',$r?json_encode($r):'none yet'); }catch(Throwable $e){}
row(is_writable(__DIR__.'/uploads'),'uploads/ folder writable (profile photos)');
row(session_status()===PHP_SESSION_ACTIVE,'Sessions working (needed for login & forms)');
?></table><p style="margin-top:20px"><b>Delete dbcheck.php from the server after you read this.</b></p></body></html>
