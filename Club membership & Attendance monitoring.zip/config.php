<?php
// InfinityFree database settings
$DB_HOST = 'sql308.infinityfree.com';
$DB_NAME = 'if0_42969602_club_membership_db';
$DB_USER = 'if0_42969602';
$DB_PASS = 'Princekoni2222';

// Set to false once everything works (hides technical error details from visitors)
$DEBUG = true;
// Anyone registering as Officer must type this code. CHANGE IT and share it only with real officers.
$OFFICER_CODE = 'SMCBI-OFFICER-2026';
// Anyone creating an ADMIN account must type this code. CHANGE IT and keep it private.
$ADMIN_CODE = 'SMCBI-ADMIN-2026';

set_exception_handler(function($e){
    http_response_code(500);
    global $DEBUG;
    echo '<!doctype html><html><body style="font-family:Arial;padding:40px;max-width:720px;margin:auto"><h2>Something went wrong</h2><p>The system could not complete this request.</p>';
    if(!empty($DEBUG)) echo '<pre style="background:#f4f4f4;padding:12px;white-space:pre-wrap">'.htmlspecialchars(get_class($e).': '.$e->getMessage().' ('.basename($e->getFile()).':'.$e->getLine().')').'</pre>';
    echo '<p><a href="index.php">Back</a></p></body></html>'; exit;
});
if (session_status() !== PHP_SESSION_ACTIVE) {
    @ini_set('session.cookie_httponly','1');
    session_start();
}

date_default_timezone_set('Asia/Manila');

try {
    $pdo = new PDO("mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4", $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    die('<!doctype html><html><body style="font-family:Arial;padding:40px"><h2>Database connection failed</h2><p>Open <b>config.php</b> and enter your InfinityFree MySQL host, database name, username, and password.</p></body></html>');
}
try { $pdo->exec("SET time_zone='+08:00'"); } catch (Throwable $e) { }
