<?php
require_once 'includes.php';

// Expected structure: table => [create SQL, required columns]
$schema = [
 'users' => ["CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY,student_id VARCHAR(40) NULL UNIQUE,full_name VARCHAR(120) NOT NULL,username VARCHAR(80) NOT NULL UNIQUE,email VARCHAR(160) NULL,password_hash VARCHAR(255) NOT NULL,role ENUM('admin','officer','adviser','member') NOT NULL DEFAULT 'member',course VARCHAR(100) NULL,year_level VARCHAR(40) NULL,profile_photo VARCHAR(255) NULL,contact_number VARCHAR(40) NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB",
   ['id','student_id','full_name','username','email','password_hash','role','course','year_level','profile_photo','contact_number','created_at']],
 'members' => ["CREATE TABLE IF NOT EXISTS members(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NULL UNIQUE,student_id VARCHAR(40) NOT NULL UNIQUE,full_name VARCHAR(120) NOT NULL,course VARCHAR(100) NOT NULL,year_level VARCHAR(40) NOT NULL,contact_number VARCHAR(40) NULL,profile_photo VARCHAR(255) NULL,club VARCHAR(60) NULL,status ENUM('Active','Inactive','Pending','Rejected') NOT NULL DEFAULT 'Pending',reason TEXT NULL,joined_on DATE NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB",
   ['id','user_id','student_id','full_name','course','year_level','contact_number','profile_photo','status','reason','joined_on','created_at']],
 'membership_applications' => ["CREATE TABLE IF NOT EXISTS membership_applications(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,member_id INT NOT NULL,reason TEXT NOT NULL,club VARCHAR(60) NULL,status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',application_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,reviewed_by INT NULL,reviewed_at TIMESTAMP NULL,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(member_id) REFERENCES members(id) ON DELETE CASCADE,FOREIGN KEY(reviewed_by) REFERENCES users(id) ON DELETE SET NULL,INDEX(status)) ENGINE=InnoDB",
   ['id','user_id','member_id','reason','status','application_date','reviewed_by','reviewed_at']],
 'activities' => ["CREATE TABLE IF NOT EXISTS activities(id INT AUTO_INCREMENT PRIMARY KEY,activity_name VARCHAR(150) NOT NULL,description TEXT NULL,activity_date DATE NOT NULL,start_time TIME NOT NULL,end_time TIME NOT NULL,location VARCHAR(150) NOT NULL,late_after TIME NOT NULL,status ENUM('Upcoming','Ongoing','Completed','Cancelled') NOT NULL DEFAULT 'Upcoming',attendance_status ENUM('Closed','Open') NOT NULL DEFAULT 'Closed',created_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,reminder_sent TINYINT(1) NOT NULL DEFAULT 0,FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL,INDEX(activity_date,status)) ENGINE=InnoDB",
   ['id','activity_name','description','activity_date','start_time','end_time','location','late_after','status','attendance_status','created_by','created_at','reminder_sent']],
 'attendance' => ["CREATE TABLE IF NOT EXISTS attendance(id INT AUTO_INCREMENT PRIMARY KEY,activity_id INT NOT NULL,user_id INT NOT NULL,status ENUM('Present','Late','Absent') NOT NULL,attendance_time DATETIME NULL,recorded_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY uq_attendance(activity_id,user_id),FOREIGN KEY(activity_id) REFERENCES activities(id) ON DELETE CASCADE,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(recorded_by) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB",
   ['id','activity_id','user_id','status','attendance_time','recorded_by','created_at']],
 'notifications' => ["CREATE TABLE IF NOT EXISTS notifications(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,title VARCHAR(160) NOT NULL,message VARCHAR(255) NOT NULL,type VARCHAR(30) NOT NULL DEFAULT 'info',is_read TINYINT(1) NOT NULL DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,INDEX idx_notifications_user(user_id,is_read,created_at)) ENGINE=InnoDB",
   ['id','user_id','title','message','type','is_read','created_at']],
 'officer_codes' => ["CREATE TABLE IF NOT EXISTS officer_codes(id INT AUTO_INCREMENT PRIMARY KEY,code VARCHAR(30) NOT NULL UNIQUE,note VARCHAR(120) NULL,created_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,expires_at DATETIME NULL,used_by INT NULL,used_at DATETIME NULL) ENGINE=InnoDB",
   ['id','code','note','created_by','created_at','expires_at','used_by','used_at']],
 'system_settings' => ["CREATE TABLE IF NOT EXISTS system_settings(id INT PRIMARY KEY,club_name VARCHAR(180) NOT NULL DEFAULT 'SMCBI Club',description VARCHAR(255) NULL) ENGINE=InnoDB",
   ['id','club_name','description']],
];

function schema_problems($pdo,$schema){
    $out=[];
    foreach($schema as $t=>$def){
        $exists=$pdo->query("SHOW TABLES LIKE ".$pdo->quote($t))->fetchColumn();
        if(!$exists) continue;
        $have=array_column($pdo->query("SHOW COLUMNS FROM `$t`")->fetchAll(),'Field');
        $missing=array_diff($def[1],$have);
        if($missing) $out[$t]=array_values($missing);
    }
    return $out;
}

$msg=''; $type='info';
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['do']??'')==='reset'){
    verify_csrf();
    if(trim($_POST['confirm']??'')==='RESET'){
        $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
        foreach(array_reverse(array_keys($schema)) as $t) $pdo->exec("DROP TABLE IF EXISTS `$t`");
        $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
        $msg='All system tables were rebuilt from scratch.'; $type='success';
    } else { $msg='Type RESET exactly to confirm.'; $type='danger'; }
}

if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['do']??'')==='repair'){
    verify_csrf();
    $defs=['student_id'=>'VARCHAR(40) NULL','email'=>'VARCHAR(160) NULL','course'=>'VARCHAR(100) NULL','year_level'=>'VARCHAR(40) NULL','profile_photo'=>'VARCHAR(255) NULL','contact_number'=>'VARCHAR(40) NULL'];
    $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
    foreach(array_reverse(array_keys($schema)) as $t){ if($t!=='users') $pdo->exec("DROP TABLE IF EXISTS `$t`"); }
    $have=array_column($pdo->query("SHOW COLUMNS FROM `users`")->fetchAll(),'Field');
    foreach($defs as $c=>$d){ if(!in_array($c,$have,true)) $pdo->exec("ALTER TABLE users ADD COLUMN `$c` $d"); }
    if(!in_array('student_id',$have,true)){ try{$pdo->exec("ALTER TABLE users ADD UNIQUE KEY uq_student_id(student_id)");}catch(PDOException $e){} }
    try{$pdo->exec("ALTER TABLE users CONVERT TO CHARACTER SET utf8mb4");}catch(PDOException $e){}
    $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
    $msg='Your existing user accounts were kept and the other tables were rebuilt.'; $type='success';
}

$problems=schema_problems($pdo,$schema);
$count=0;
if(!$problems){
    foreach($schema as $t=>$def) $pdo->exec($def[0]);
    $pdo->exec("INSERT IGNORE INTO system_settings(id,club_name,description) VALUES(1,'SMCBI Club','Club Membership and Attendance Monitoring System')");
    $count=(int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['do']??'')==='admin' && $count===0){
        verify_csrf();
        $name=trim($_POST['full_name']??'');$username=trim($_POST['username']??'');$email=strtolower(trim($_POST['email']??''));$pass=$_POST['password']??'';
        if($name&&$username&&filter_var($email,FILTER_VALIDATE_EMAIL)&&preg_match('/@smcbi\.edu\.ph$/',$email)&&strlen($pass)>=8){
            $pdo->prepare("INSERT INTO users(full_name,username,email,password_hash,role) VALUES(?,?,?,?,'admin')")->execute([$name,$username,$email,password_hash($pass,PASSWORD_DEFAULT)]);
            $count=1;$msg='Administrator created. You can now log in. For security, delete setup.php from the server.';$type='success';
        } else { $msg='Enter all fields, a school email (@smcbi.edu.ph), and a password of at least 8 characters.'; $type='danger'; }
    }
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Setup | Club Membership &amp; Attendance</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link rel="icon" type="image/svg+xml" href="favicon.svg"><link rel="stylesheet" href="smcbi-theme.css?v=<?=css_ver()?>"></head><body><div class="login-shell"><div class="login-card card p-4 p-md-5"><div class="text-center mb-4"><div class="mx-auto mb-3 brand-logo-lg"><?=brand_logo()?></div><h2>Club Membership &amp; Attendance Setup</h2><p class="text-muted">Prepare the SMCBI club membership and attendance database.</p></div>
<?php if($msg):?><div class="alert alert-<?=e($type)?>"><?=e($msg)?></div><?php endif;?>
<?php if($problems):?>
<div class="alert alert-warning"><strong>Old database structure found.</strong> These existing tables do not match this version (that is what caused the "Unknown column" login error):<ul class="mb-0 mt-2"><?php foreach($problems as $t=>$cols):?><li><code><?=e($t)?></code> is missing: <?=e(implode(', ',$cols))?></li><?php endforeach;?></ul></div>
<?php if(isset($problems['users'])||$problems):?><form method="post" class="mb-3"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="do" value="repair"><button class="btn btn-primary w-100">Keep my existing accounts &amp; rebuild everything else (recommended)</button><div class="small text-muted mt-1">Keeps users and passwords (admin, officers); deletes old activities, members and attendance test data.</div></form><hr><?php endif;?>
<p class="small text-muted">Or start completely fresh: Resetting deletes all system tables and data in this database and rebuilds them, including user accounts.</p>
<form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="do" value="reset"><label class="form-label">Type <strong>RESET</strong> to confirm</label><input class="form-control mb-3" name="confirm" autocomplete="off" required><button class="btn btn-danger w-100">Reset &amp; Rebuild Database</button></form>
<?php elseif($count===0):?>
<p class="text-muted">Tables are ready. Create the first Administrator account.</p>
<form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="do" value="admin"><label class="form-label">Administrator Name</label><input class="form-control mb-3" name="full_name" required><label class="form-label">Username</label><input class="form-control mb-3" name="username" required><label class="form-label">Email</label><input type="email" class="form-control mb-3" name="email" placeholder="example@smcbi.edu.ph" pattern="[A-Za-z0-9._%+\-]+@smcbi\.edu\.ph" title="Use your school email: example@smcbi.edu.ph" required><label class="form-label">Password (min 8)</label><input type="password" class="form-control mb-4" name="password" minlength="8" required><button class="btn btn-primary w-100">Create Admin</button></form>
<?php else:?>
<div class="alert alert-success">Database is ready.</div><a class="btn btn-primary w-100" href="login.php?role=admin">Open Admin Login</a>
<?php endif;?></div></div></body></html>
