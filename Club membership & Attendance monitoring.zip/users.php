<?php
require_once 'includes.php'; require_admin();
$programs=program_list();
$roleLabels=['member'=>'Student','officer'=>'Officer','adviser'=>'Adviser','admin'=>'Administrator'];
function taken($pdo,$table,$col,$val){ $q=$pdo->prepare("SELECT COUNT(*) FROM $table WHERE $col=?"); $q->execute([$val]); return (int)$q->fetchColumn()>0; }

if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf(); $action=$_POST['action']??'';

    if($action==='create'){
        $name=trim($_POST['full_name']??''); $username=trim($_POST['username']??''); $email=trim($_POST['email']??''); if(norm_email($email)!==null)$email=norm_email($email);
        $pass=$_POST['password']??''; $role=$_POST['role']??'member'; $kind=(($_POST['kind']??'student')==='staff')?'staff':'student'; if($kind==='student') $role='member'; $club=trim($_POST['club']??''); $contact=norm_phone($_POST['contact_number']??'');
        $sid=norm_student_id($_POST['student_id']??''); $course=trim($_POST['course']??''); $year=trim($_POST['year_level']??'');
        $isStudent=($role==='member'); $activate=$isStudent && !empty($_POST['activate']); $err=''; $photo=null;
        if(!isset($roleLabels[$role])||($kind==='staff'&&$role==='member')) $err='Choose a valid role.';
        elseif(!$name||!$username||norm_email($email)===null||strlen($pass)<8) $err='Complete all fields: a school email (@smcbi.edu.ph) and a password of at least 8 characters.';
        elseif($isStudent&&$sid===null) $err='Student ID must be the letter C followed by exactly 6 numbers (example: C240111).';
        elseif($contact===null) $err='Contact number must be exactly 11 digits (example: 09123456789).';
        elseif($isStudent&&(!$sid||!in_array($course,$programs,true)||!$year)) $err='Students need a Student ID, program and year level.';
        elseif($activate&&!in_array($club,club_list(),true)) $err='Select a club for the active member.';
        if(!$err&&$isStudent){ $photo=save_photo($_FILES['profile_photo']??null,'adm'); if($photo===false) $err='Photo must be JPG, PNG or WEBP, max 2 MB.'; }
        if(!$err){
            if(taken($pdo,'users','username',$username)) $err='That username is already taken.';
            elseif(taken($pdo,'users','email',$email)) $err='That email is already registered.';
            elseif($isStudent&&(taken($pdo,'users','student_id',$sid)||taken($pdo,'members','student_id',$sid))) $err='That Student ID is already registered.';
        }
        if($err){ flash($err,'danger'); }
        else{
            try{
                $pdo->beginTransaction();
                $pdo->prepare('INSERT INTO users(student_id,full_name,username,email,password_hash,role,course,year_level,contact_number,profile_photo) VALUES(?,?,?,?,?,?,?,?,?,?)')
                    ->execute([$isStudent?$sid:null,$name,$username,$email,password_hash($pass,PASSWORD_DEFAULT),$role,$isStudent?$course:null,$isStudent?$year:null,$contact,$photo]);
                $uid=(int)$pdo->lastInsertId();
                if($activate){
                    $pdo->prepare("INSERT INTO members(user_id,student_id,full_name,course,year_level,contact_number,profile_photo,club,status,joined_on) VALUES(?,?,?,?,?,?,?,?,'Active',CURDATE())")
                        ->execute([$uid,$sid,$name,$course,$year,$contact,$photo,$club]);
                    notify_user($uid,'Membership Approved','You are now an active member of '.$club.'. Your attendance can be recorded.','membership');
                }
                $pdo->commit();
                flash($roleLabels[$role].' account created for '.$name.($activate?' and added to '.$club.'.':'.'));
            }catch(PDOException $e){
                if($pdo->inTransaction()) $pdo->rollBack();
                flash('Could not create the account.'.(!empty($DEBUG)?' '.$e->getMessage():''),'danger');
            }
        }
    }
    elseif($action==='role'){
        $id=(int)$_POST['id']; $role=$_POST['role']??'';
        if(isset($roleLabels[$role])&&$id!==(int)$_SESSION['user_id']){ $pdo->prepare('UPDATE users SET role=? WHERE id=?')->execute([$role,$id]); flash('User role updated.'); }
    }
    elseif($action==='club'){
        $id=(int)$_POST['id']; $club=trim($_POST['club']??'');
        if($club!==''&&!in_array($club,club_list(),true)){ flash('Choose a valid club.','danger'); }
        else{
            $us=$pdo->prepare("SELECT * FROM users WHERE id=? AND role='member'"); $us->execute([$id]); $su=$us->fetch();
            if(!$su){ flash('Student not found.','danger'); }
            else{
                $ms=$pdo->prepare('SELECT * FROM members WHERE user_id=?'); $ms->execute([$id]); $mem=$ms->fetch();
                try{
                    if($mem){
                        $pdo->prepare('UPDATE members SET club=? WHERE id=?')->execute([$club!==''?$club:null,$mem['id']]);
                        if($club!==''&&$club!==$mem['club']) notify_user($id,'Club Updated','Your club is now '.$club.'.','membership');
                        flash($club!==''?$su['full_name'].' is now in '.$club.'.':'Club removed for '.$su['full_name'].'.');
                    }elseif($club===''){
                        flash('This student has no club to remove.','info');
                    }else{
                        // No membership record yet: assigning a club adds the student as an active member of it.
                        $sid=$su['student_id']?:'STU-'.str_pad((string)$id,5,'0',STR_PAD_LEFT);
                        $pdo->prepare("INSERT INTO members(user_id,student_id,full_name,course,year_level,contact_number,profile_photo,club,status,joined_on) VALUES(?,?,?,?,?,?,?,?,'Active',?)")
                            ->execute([$id,$sid,$su['full_name'],$su['course']?:'Not Set',$su['year_level']?:'Not Set',$su['contact_number'],$su['profile_photo'],$club,date('Y-m-d')]);
                        notify_user($id,'Club Membership','You were added as an active member of '.$club.'.','membership');
                        flash($su['full_name'].' was added as an active member of '.$club.'.');
                    }
                }catch(PDOException $e){ flash('Could not update the club.'.(!empty($DEBUG)?' '.$e->getMessage():''),'danger'); }
            }
        }
    }
    elseif($action==='reset'){
        $id=(int)$_POST['id']; $np=$_POST['new_password']??'';
        if($id===(int)$_SESSION['user_id']) flash('Use your Profile page to change your own password.','warning');
        elseif(strlen($np)<8) flash('Password must be at least 8 characters.','danger');
        else{ $pdo->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($np,PASSWORD_DEFAULT),$id]); flash('Password reset.'); }
    }
    elseif($action==='gencode'){
        ensure_officer_codes(); $note=mb_substr(trim($_POST['note']??''),0,120); $days=(int)($_POST['days']??7); if(!in_array($days,[1,3,7,30],true))$days=7;
        $code=''; for($t=0;$t<5;$t++){ $code=gen_officer_code(); try{ $pdo->prepare('INSERT INTO officer_codes(code,note,created_by,expires_at) VALUES(?,?,?,DATE_ADD(NOW(),INTERVAL '.$days.' DAY))')->execute([$code,$note!==''?$note:null,$_SESSION['user_id']]); $_SESSION['new_code']=[$code,$note,$days]; break; }catch(PDOException $e){ $code=''; } }
        if($code==='') flash('Could not create a code. Please try again.','danger');
    }
    elseif($action==='revokecode'){
        ensure_officer_codes(); $pdo->prepare('DELETE FROM officer_codes WHERE id=? AND used_by IS NULL')->execute([(int)$_POST['id']]); flash('Officer code removed.');
    }
    elseif($action==='delete'){
        $id=(int)$_POST['id'];
        $t=$pdo->prepare('SELECT role FROM users WHERE id=?'); $t->execute([$id]); $trole=$t->fetchColumn();
        $admins=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
        if($id===(int)$_SESSION['user_id']||!$trole) flash('You cannot delete this account.','danger');
        elseif($trole==='admin'&&$admins<=1) flash('The last administrator cannot be deleted.','danger');
        else{
            $pdo->beginTransaction();
            $pdo->prepare('DELETE FROM members WHERE user_id=?')->execute([$id]);
            $pdo->prepare('DELETE FROM users WHERE id=?')->execute([$id]);
            $pdo->commit(); flash('Account deleted.','warning');
        }
    }
    redirect('users.php');
}

$q=trim($_GET['q']??''); $rf=$_GET['role']??'';
$cf=$_GET['club']??'';
$sql='SELECT u.id,u.student_id,u.full_name,u.username,u.email,u.role,u.course,u.year_level,u.created_at,m.club FROM users u LEFT JOIN members m ON m.user_id=u.id WHERE 1'; $params=[];
if($q!==''){ $sql.=' AND (u.full_name LIKE ? OR u.username LIKE ? OR u.email LIKE ? OR u.student_id LIKE ?)'; $l="%$q%"; $params=[$l,$l,$l,$l]; }
if(isset($roleLabels[$rf])){ $sql.=' AND u.role=?'; $params[]=$rf; }
if(in_array($cf,club_list(),true)){ $sql.=' AND m.club=?'; $params[]=$cf; }
$sql.=' ORDER BY u.created_at DESC,u.id DESC'; $cs=$pdo->prepare('SELECT COUNT(*) FROM ('.$sql.') t'); $cs->execute($params); $pg=paginate((int)$cs->fetchColumn(),25); $sql.=' LIMIT '.(int)$pg['per'].' OFFSET '.(int)$pg['offset']; $st=$pdo->prepare($sql); $st->execute($params); $rows=$st->fetchAll();
$counts=$pdo->query('SELECT role,COUNT(*) c FROM users GROUP BY role')->fetchAll(PDO::FETCH_KEY_PAIR);
ensure_officer_codes(); try{ $codes=$pdo->query('SELECT c.*,u.full_name used_name FROM officer_codes c LEFT JOIN users u ON u.id=c.used_by ORDER BY c.id DESC LIMIT 40')->fetchAll(); }catch(PDOException $e){ $codes=[]; }
$newCode=$_SESSION['new_code']??null; unset($_SESSION['new_code']);
header_html('User Management');
?>
<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
  <div><h2>User &amp; Role Management</h2><div class="text-muted">Create and manage Student, Officer, Adviser and Administrator accounts.</div></div>
  <div class="d-flex flex-wrap gap-2"><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#studentModal">Create Student Account</button><button class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#staffModal">Create Admin / Staff Account</button><button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#codesModal"><i class="bi bi-key me-1"></i>Officer Codes</button></div>
</div>
<?php if($newCode):?><div class="alert alert-success d-flex flex-wrap align-items-center justify-content-between gap-2"><div><strong>New officer code<?=$newCode[1]!==''?' for '.e($newCode[1]):''?>:</strong> <code class="fs-5 user-select-all" id="newCodeText"><?=e($newCode[0])?></code><div class="small">One-time use. Expires in <?=(int)$newCode[2]?> day(s). Give it to the officer; it works only once on the Officer sign-up page.</div></div><button type="button" class="btn btn-success btn-sm" onclick="navigator.clipboard&&navigator.clipboard.writeText(document.getElementById('newCodeText').textContent);this.textContent='Copied'">Copy code</button></div><?php endif;?>
<div class="row g-3 mb-3">
<?php foreach($roleLabels as $k=>$lbl):?><div class="col-6 col-md-3"><div class="card p-3"><div class="small-muted"><?=e($lbl)?>s</div><div class="stat-value"><?=(int)($counts[$k]??0)?></div></div></div><?php endforeach;?>
</div>
<form class="d-flex flex-wrap gap-2 mb-3" method="get"><input class="form-control" style="min-width:180px;flex:1 1 200px" name="q" value="<?=e($q)?>" placeholder="Search name, username, email, student ID"><select class="form-select w-auto" name="role"><option value="">All roles</option><?php foreach($roleLabels as $k=>$lbl):?><option value="<?=$k?>" <?=$rf===$k?'selected':''?>><?=e($lbl)?></option><?php endforeach;?></select><select class="form-select w-auto" name="club"><option value="">All clubs</option><?php foreach(club_list() as $c):?><option <?=$cf===$c?'selected':''?>><?=e($c)?></option><?php endforeach;?></select><button class="btn btn-primary">Filter</button></form>
<div class="card p-3 table-responsive">
<table class="table align-middle"><thead><tr><th>User</th><th>Email</th><th>Role</th><th>Program / Year</th><th>Club</th><th>Created</th><th>Actions</th></tr></thead><tbody>
<?php foreach($rows as $u):?><tr>
<td><strong><?=e($u['full_name'])?></strong><div class="small-muted"><?=e($u['username'])?><?=$u['student_id']?' · '.e($u['student_id']):''?></div></td>
<td style="min-width:150px;overflow-wrap:break-word"><?=str_replace(array('@','.'),array('<wbr>@','<wbr>.'),e($u['email']))?></td>
<td><span class="badge bg-secondary"><?=e($roleLabels[$u['role']]??$u['role'])?></span></td>
<td><?php if($u['course']):?><span title="<?=e($u['course'])?>"><strong><?=e(explode(' - ',$u['course'])[0])?></strong></span><div class="small-muted"><?=e($u['year_level'])?><?php if(academic_club($u['course'])):?> · <?=e(academic_club($u['course']))?><?php endif;?></div><?php else:?>—<?php endif;?></td>
<td class="text-nowrap"><?php if($u['role']==='member'):?><?=$u['club']?'<span class="badge bg-info text-dark">'.e($u['club']).'</span>':'<span class="small-muted">No club</span>'?> <button type="button" class="btn btn-sm btn-outline-primary ms-1" data-bs-toggle="modal" data-bs-target="#clubModal" data-id="<?=$u['id']?>" data-name="<?=e($u['full_name'])?>" data-club="<?=e($u['club']??'')?>">Edit club</button><?php else:?><span class="small-muted">—</span><?php endif;?></td>
<td class="text-nowrap"><?=e(date('M d, Y',strtotime($u['created_at'])))?></td>
<td style="min-width:210px"><?php if((int)$u['id']!==(int)$_SESSION['user_id']):?>
<div class="d-flex flex-column gap-2 align-items-start"><form method="post" class="d-flex gap-1"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="role"><input type="hidden" name="id" value="<?=$u['id']?>"><select class="form-select form-select-sm" style="width:auto" name="role"><?php foreach($roleLabels as $k=>$lbl):?><option value="<?=$k?>" <?=$u['role']===$k?'selected':''?>><?=e($lbl)?></option><?php endforeach;?></select><button class="btn btn-sm btn-outline-primary">Save</button></form>
<div class="d-flex gap-1"><button class="btn btn-sm btn-outline-secondary text-nowrap" data-bs-toggle="modal" data-bs-target="#pwModal" data-id="<?=$u['id']?>" data-name="<?=e($u['full_name'])?>">Reset password</button>
<form method="post" class="d-inline"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$u['id']?>"><button class="btn btn-sm btn-outline-danger" data-confirm="Delete this account and its membership/attendance records? This cannot be undone.">Delete</button></form></div></div>
<?php else:?><span class="small-muted">Current account</span><?php endif;?></td></tr>
<?php endforeach; if(!$rows):?><tr><td colspan="7" class="empty-state">No accounts found.</td></tr><?php endif;?>
</tbody></table><?=pager_bar($pg,'users')?></div>

<div class="modal fade" id="studentModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg"><div class="modal-content"><form method="post" enctype="multipart/form-data">
<input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="create"><input type="hidden" name="kind" value="student">
<div class="modal-header"><h5 class="modal-title">Create Student Account</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
<div class="modal-body row g-3">
 <div class="col-md-6"><label class="form-label">Student ID *</label><?=sid_input('',true)?></div>
 <div class="col-md-6"><label class="form-label">Full Name *</label><input class="form-control" name="full_name" required></div>
 <div class="col-md-6"><label class="form-label">Program / Course *</label><select class="form-select" name="course" required><option value="">Select program</option><?php foreach($programs as $p):?><option><?=e($p)?></option><?php endforeach;?></select></div>
 <div class="col-md-6"><label class="form-label">Academic Club <span class="small-muted">(automatic)</span></label><?=academic_club_field()?></div>
 <div class="col-md-6"><label class="form-label">Year Level *</label><select class="form-select" name="year_level" required><option value="">Select</option><option>1st Year</option><option>2nd Year</option><option>3rd Year</option><option>4th Year</option></select></div>
 <div class="col-md-6"><label class="form-label">Username *</label><input class="form-control" name="username" required></div>
 <div class="col-md-6"><label class="form-label">Email *</label><?=email_input('email')?></div>
 <div class="col-md-6"><label class="form-label">Temporary Password * (min 8)</label><input type="password" class="form-control" name="password" minlength="8" required></div>
 <div class="col-md-6"><label class="form-label">Contact Number</label><?=phone_input()?></div>
 <div class="col-md-6"><label class="form-label">Profile Photo (optional)</label><input type="file" class="form-control" name="profile_photo" accept="image/jpeg,image/png,image/webp"></div>
 <div class="col-md-6"><label class="form-label">Club</label><select class="form-select" name="club"><option value="">— none —</option><?php foreach(club_list() as $c):?><option><?=e($c)?></option><?php endforeach;?></select></div>
 <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" name="activate" value="1" id="act"><label class="form-check-label" for="act">Add as an <strong>active member</strong> of the selected club right away (skips the application).</label></div></div>
</div>
<div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Create Student</button></div>
</form></div></div></div>

<div class="modal fade" id="staffModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered modal-dialog-scrollable"><div class="modal-content"><form method="post">
<input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="create"><input type="hidden" name="kind" value="staff">
<div class="modal-header"><h5 class="modal-title">Create Admin / Staff Account</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
<div class="modal-body row g-3">
 <div class="col-12"><label class="form-label">Role *</label><select class="form-select" name="role"><option value="admin">Administrator</option><option value="officer" selected>Officer</option><option value="adviser">Adviser</option></select></div>
 <div class="col-12"><label class="form-label">Full Name *</label><input class="form-control" name="full_name" required></div>
 <div class="col-md-6"><label class="form-label">Username *</label><input class="form-control" name="username" required></div>
 <div class="col-md-6"><label class="form-label">Email *</label><?=email_input('email')?></div>
 <div class="col-md-6"><label class="form-label">Temporary Password * (min 8)</label><input type="password" class="form-control" name="password" minlength="8" required></div>
 <div class="col-md-6"><label class="form-label">Contact Number</label><?=phone_input()?></div>
</div>
<div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-dark">Create Account</button></div>
</form></div></div></div>

<div class="modal fade" id="codesModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg"><div class="modal-content">
<div class="modal-header"><h5 class="modal-title">Officer Codes</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
<div class="modal-body">
<form method="post" class="row g-2 align-items-end mb-3"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="gencode">
 <div class="col-md-6"><label class="form-label">For (officer name, optional)</label><input class="form-control" name="note" maxlength="120" placeholder="e.g. Juan Dela Cruz"></div>
 <div class="col-6 col-md-3"><label class="form-label">Valid for</label><select class="form-select" name="days"><option value="1">1 day</option><option value="3">3 days</option><option value="7" selected>7 days</option><option value="30">30 days</option></select></div>
 <div class="col-6 col-md-3"><button class="btn btn-primary w-100">Generate code</button></div></form>
<div class="small-muted mb-2">Each code works once on the Officer sign-up page, then it is used up.</div>
<div class="table-responsive"><table class="table table-sm align-middle mb-0"><thead><tr><th>Code</th><th>For</th><th>Status</th><th>Expires</th><th></th></tr></thead><tbody>
<?php foreach($codes as $c): $used=!empty($c['used_by']); $exp=!$used&&$c['expires_at']&&strtotime($c['expires_at'])<time();?>
<tr><td><code class="user-select-all"><?=e($c['code'])?></code></td><td><?=e($c['note']?:'—')?></td><td><?php if($used):?><span class="badge bg-secondary">Used by <?=e($c['used_name']?:'(deleted)')?></span><?php elseif($exp):?><span class="badge bg-warning text-dark">Expired</span><?php else:?><span class="badge bg-success">Unused</span><?php endif;?></td><td class="text-nowrap"><?=e($c['expires_at']?date('M d, Y',strtotime($c['expires_at'])):'—')?></td><td class="text-end"><?php if(!$used):?><form method="post" class="d-inline"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="revokecode"><input type="hidden" name="id" value="<?=(int)$c['id']?>"><button class="btn btn-sm btn-outline-danger" data-confirm="Remove this officer code?">Remove</button></form><?php endif;?></td></tr>
<?php endforeach; if(!$codes):?><tr><td colspan="5" class="text-center text-muted py-3">No codes yet. Generate one above.</td></tr><?php endif;?>
</tbody></table></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button></div></div></div></div>

<div class="modal fade" id="clubModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered modal-dialog-scrollable"><div class="modal-content"><form method="post">
<input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="club"><input type="hidden" name="id" id="clubId">
<div class="modal-header"><h5 class="modal-title">Edit club: <span id="clubName"></span></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><label class="form-label">Club</label><select class="form-select" name="club" id="clubSel"><option value="">— No club —</option><?php foreach(club_list() as $c):?><option><?=e($c)?></option><?php endforeach;?></select>
<div class="small-muted mt-2">If this student has no membership yet, choosing a club adds them as an active member of that club.</div></div>
<div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Save Club</button></div>
</form></div></div></div>

<div class="modal fade" id="pwModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered modal-dialog-scrollable"><div class="modal-content"><form method="post">
<input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="reset"><input type="hidden" name="id" id="pwId">
<div class="modal-header"><h5 class="modal-title">Reset password: <span id="pwName"></span></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><label class="form-label">New password (min 8)</label><input type="password" class="form-control" name="new_password" minlength="8" required></div>
<div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Reset</button></div>
</form></div></div></div>
<?=academic_club_js()?>
<script>
(function(){
 document.getElementById('clubModal').addEventListener('show.bs.modal',function(ev){var b=ev.relatedTarget;document.getElementById('clubId').value=b.dataset.id;document.getElementById('clubName').textContent=b.dataset.name;document.getElementById('clubSel').value=b.dataset.club||'';});
 document.getElementById('pwModal').addEventListener('show.bs.modal',function(ev){var b=ev.relatedTarget;document.getElementById('pwId').value=b.dataset.id;document.getElementById('pwName').textContent=b.dataset.name;});
})();
</script>
<?php footer_html();
